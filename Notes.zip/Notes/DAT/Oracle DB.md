# Oracle DB

- Výrobcem Oracle Corporation
- Výkonná
- Komerční produkt
- SQL, PL/SQL, XML,..
- Databázové modely
	- Relační
	- Objektové
	- Hierarchické

- Multiplatformní
	- Apple, OpenVMS, Linux, Windows, Sun Solaris
- Prvenství Oracle
	- První komerční SQL databáze (1979)
	- Symetrický multiprocessing (1983)
	- Distribuovaná databáze (1986)
	- 64-bitová (1995)
	- Webová databáze (1997)
	- Podpora XML (1999)


---
#DAT 