# MySQL

- Výrobce je švédská firma MySQL AB
- První verze 1995
- License GPL i komerční (pro Enterprise)
- Multiplatformní
- [[Relační DB]] používá
- Používá SQL s rozšířeními
- Velmi častá kombinace = Apache + PHP + MySQL (XAMPP, WAMP)
- Optimalizováno na rychlost
- Současná verze MySQL Server 8.0

### Funkce MySQL
- Cizí klíče, Transakce, Různé znakové sady, Poddotazy, Uložené procedury,...


---
#DAT 