# Microsoft SQL Server

- Komerční produkt firmy Microsoft
- Relační model dat
- Transact-SQL

- Základem je Sybase (pod OS Unix)
	- Microsoft jej upravil pro Windows NT (1993)

- Komplexní nástroj pro vedení firmy


---

#DAT 