# Parcialita

- O entitních typech, které jsou zapojeny do vztahu říkáme, že jsou členy vztahu.

- Členství může být buď povinné nebo nepovinné.

- Ne levé straně je několik možných způsobů zobrazení jedné stejné situace:
	- Každý zaměstnanec musí být zařazen do některého oddělení
	- Oddělení může existovat i bez zaměstnanců
	
![[Parcialita.png]]

---
#DAT 