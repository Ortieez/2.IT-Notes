# Microsoft Access

- Komerční produkt firmy Microsoft
- Součást balíku MS Office
- Relační model dat
- Grafické rozhraní
	- Návrh dotazovacích formulářů, tabulek, sestav, …

- Umí přistupovat k datům přes ODBC API
	- Open Database Connectivity
	- Oracle Database, MS SQL Server, …

- Podpora SQL


---

#DAT 