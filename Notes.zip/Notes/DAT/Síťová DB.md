# Síťová DB

- Schéma databáze se skládá z typů záznamů, které obsahují popis atributů(datových položek) a množin, které definují vztahy mezi záznamy.

- Data jsou uspořádána jako uzly rovinného grafu, ve kterém může být každý záznam spojený s libovolným počtem dalších záznamů.

- Každý záznam má přiřazený databázový klíč, který slouží pro jeho adresaci ve vztazích.

![[Sitova_DB.png]]

---
#DAT 
