# Identifikační klíč

- Atribut (skupina atributů), jehož hodnota slouží k identifikaci konkrétní entity se nazývá identifikační klíč (primární klíč).

- Konkrétní výskyt vztahu může být identifikován klíči entit, které ve vztahu vystupují.

---
#DAT 