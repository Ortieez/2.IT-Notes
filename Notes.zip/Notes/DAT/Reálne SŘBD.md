# Reálne SŘBD

### Důležité SŘBD
- [[MySQL]], MariaDB
- [[Oracle DB]]
- [[Microsoft Access]], Open Office Base
- [[Microsoft SQL Server]]
- [[PostgreSQL]]
- Sybase SQL Server
- IBM DB
- IBM Informix

---
#DAT 