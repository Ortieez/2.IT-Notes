# Kardinalita v E-R Diagramu

- Pro vztah 1: 1 můžeme formulovat tato tvrzení:
	- Název kina jednoznačně určuje jméno filmu
	- Jméno filmu jednoznačně určuje název kina
	- Existuje obousměrné funkční přiřazení mezi oběma entitními typy
	
---

- Pro vztah 1:N můžeme formulovat tato tvrzení:
	- Název kina neurčuje jméno filmu
	- Jméno filmu jednoznačně určuje název kina
	- Existuje jednoznačná funkční závislost kina na filmu.

---

- Pro vztah M:N můžeme formulovat tato tvrzení:
	- Název kina neurčuje jméno filmu
	- Jméno filmu neurčuje název kina
	- Neexistuje jednoznačná funkční závislost mezi oběma entitními typy.

![[Kardinalita.png]]

---

#DAT 