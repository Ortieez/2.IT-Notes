# Hierarchická DB

- V hierarchickém jsou modelu data organizována do stromu.

![[Hierarchicka_DB.png]]

---
#DAT 