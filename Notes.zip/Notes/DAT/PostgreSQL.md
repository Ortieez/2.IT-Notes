# PostgreSQL

- Relační model dat
- Otevřený kód, BSD licence
- Spolehlivost, bezpečnost
- Multiplatformní
	- Linux, Windows, Unix, …

- Kvalitní free dokumentace
- Podpora běhu procedur dalších jazyků
	- Python, Perl, C, PL/pgSQL

- Rozšiřitelný
	- Nové datové typy, funkce, …

---
#DAT 