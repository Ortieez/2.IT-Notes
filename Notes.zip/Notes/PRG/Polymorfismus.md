# Polymorfismus

- Obecně je v kontextu OOP polymorfismus vlastnost, která umožňuje objektům volání jedné metody se stejným jménem, ale s jinou implementací.

Polymorfizmus umožňuje:
- jednomu objektu volat jednu metodu s různými parametry,
- objektům odvozeným z různých tříd volat tutéž metodu se stejným významem v kontextu jejich třídy,
- provedení rozdílné operace v závislosti na typu operandů (tzv. přetěžování operátorů).

---
#PRG 