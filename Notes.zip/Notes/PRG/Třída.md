# Třída

- Třída slouží jako šablona (předloha) pro vytváření objektů (instancí třídy).

- Seskupuje objekty stejného typu a podchycuje jejich podstatu na obecné úrovni. 

- Třída definuje data (vlastnosti) a metody (chování) objektů.


---
#PRG 