# Dědičnost

- Objekty jsou organizovány do stromové struktury. Každý objekt může dědit vlastnosti a chování jednoho nebo více jiných objektů a přidat svá vlastní rozšíření.

- Příklad:
	- Člověk dědí vlastnosti a chování po svých biologických rodičích.

---
#PRG 