# Abstrakce

- Každý objekt pracuje jako černá skříňka, která dokáže provádět určené činnosti a komunikovat s okolím, aniž by byla vyžadována znalost způsobu, kterým vnitřně pracuje. 

- Objekt můžeme používat, aniž bychom znali detaily jeho fungování.

- Implementaci objektu lze změnit, pokud nezměníme rozhraní.

---
#PRG