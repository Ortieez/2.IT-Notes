# Zapouzdření

- Objekt je zapouzdřen. K objektu se přistupuje pomocí rozhraní, které umožňuje s objektem pracovat.

- Přímý přístup k vlastnostem objektu není vhodný, mohl by vést k nekonzistenci.


---
#PRG 