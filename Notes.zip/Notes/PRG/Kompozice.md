# Kompozice

- Kompozice umožňuje kombinovat jednoduché objekty do složitějších struktur. 

- Vznikají tak pokročilé datové struktury (spojový seznam, binární strom), s nimiž se pracuje stejně jako se základními objekty.

- Příklad:
	- Auto má karburátor.
	- Karburátor je vytvořen, když je vytvořeno Auto.
	- Pokud zničíme (smažeme) auto, je zničen (smazán) i karburátor.

---
#PRG 