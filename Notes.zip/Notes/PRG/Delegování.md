# Delegování
- Objekt může delegovat provedení operace (požádat o provedení) na jiný objekt.

---

#PRG 