# Objekt

- Jednotlivé prvky modelované reality (jak data, tak související funkčnost) jsou v programu seskupeny do entit, nazývaných objekty.

- Objekt je prvek schopný samostatné existence, jednoznačně identifikovatelný svými vlastnostmi a chováním. 

- Objekty si pamatují svůj stav a navenek poskytují operace v podobě metod, které lze nad objektem volat.

---
#PRG 