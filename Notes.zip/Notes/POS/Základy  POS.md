# Základy POS

### **Zbytek POS je zde** [Netacad](https://netacad.com)

### Základní elementy počítačového systému

1. **Zařízení** (nádraží, depa, parkoviště,...)
	- Koncová (komunikace zde končí, ale i začíná - zdroj či cíl)
	- Zprostředkovatelská

2. **Média** (silnice, koleje, cesty)
	- Kabelová (Drátová)
		1. Metalické (měď, zlato - data jsou elektrické signály)
			- Twisted pair (TP)
			- Foiled twisted pair (FTP)
			- Coax
			
		2. Optické (plast, sklo - data jsou světelné signály)
		
	- Bezdrátová
		1. Wi-Fi
		2. Bluetooth
		3. Světlo
	 
3. **Data** (auta, kola, motorky)
4. **Pravidla** (Protokoly) (dopravní pravidla)

---

### Rozdělení sítí podle velikosti
4.PAN (Personal Area Network)
3.LAN (Local Area Network)
~~2.MAN (Metropolitan Area Network)~~ (Neřeší se)
1.WAN (Wide Area Network)


---
#POS
