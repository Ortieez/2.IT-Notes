 - je neurčitý tvar slovesa, který nevyjadřuje osobu, číslo, způsob ani čas
 
 #ČJ 