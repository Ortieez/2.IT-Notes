# Slovotvorný prostředek

- Může být:
	- Předpona
	- Přípona
	- Koncovka tvořící nové slovo (trn -> trn-í), nikoliv tvořící nový význam 
	  (mal-ý -> mal-ému)
	- Hláskové rozdíly oproti slovotvornému základu (mod**r**ý -> mod**ř**e)

- Slovotvorných základů i prostředků ve 
  slově více: moře + plavba = mořeplavba, město -> náměstí
  
---
#ČJ 
