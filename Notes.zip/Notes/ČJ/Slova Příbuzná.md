# Slova Příbuzná

- Blízký význam
- Utvořená i neutvořená 
- Shodný kořen
- Např. Příbuznost u vyjmenovaných slov (lyže -> lyžař, lyžovat)

---
#ČJ 