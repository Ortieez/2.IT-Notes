# Slohové postupy a útvary

- [[Slohový postup]] - představuje zásady, jimiž se řídí tvorba sdělení po stráne tematické i jazykové
- [[Slohový útvar]] - typ sdělení s charakteristickými rysy užívaný v ustálených komunikačních situacích

---
#ČJ 