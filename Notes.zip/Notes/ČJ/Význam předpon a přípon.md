# Význam předpon a přípon

- Mají svůj věcný význam - stává se součástí významu slova utvořeného
- [[Slovotvorný prostředek|Slovotvorné prostředky]] = významové rozdíly mezi základovým a odvozeným slovem


---
#ČJ 