# Typy Projevů
- Slohové útvary *oznamovací*:
	- hlášení
	- zpráva
	- oznámení
	- objednávka
	- výkaz

---
- Útvary *dokumentární*:
	- Zápis
	- Usnesení
	- Protokol
	- Smlouva
	- Potrvzení
---

#ČJ 