# Slohový Postup

- Informační - Předávání nějaké informace 
- Popisný - Popis prostředí, pracovního postupu, situace
- Vyprávěcí
- Výkladový
- Úvahový
- [[Administrativní Styl|Administrativní]] - úřední (např. žádost) 

---
#ČJ 