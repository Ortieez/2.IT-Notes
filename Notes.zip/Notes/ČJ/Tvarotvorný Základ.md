# Tvarotvorný Základ
- tvarotvorný základ když skloňujeme nebo časujeme tak se nemění

1. samotný kořen (např. **les**-a, **les**-em)
2. předpona a kořen (např. **pra-les**-a, **pra-les**-em)
3. kořenem a slovotvornou příponou (např. **les-ník**-a, **les-ník**-em)
4. kořenem a kmenotvornou příponou (např. **děl-a**-l, **rajč-et**-e, **tém-at**-u)
5. kombinací kořene a několika předpon nebo přípon, přip. obojího (např. **ne-roz-bit-n**-ých)

#ČJ 