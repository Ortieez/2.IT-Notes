# Koncovka
- koncovky nesou mluvnický význam tvarů
- upozorňují na pád a číslo
- někdy při ohýbání může dojít ke **střídání hlásek** v [[Tvarotvorný Základ|tvarotvorném základu]] (např. dům x domů, brát x bral)
- **nulová koncovká** - Ø

#ČJ 