# Slovotvorný Základ

- Může být tvořen:
	1. Jen kořenem (**moř**-e -> **moř**-ský)
	2. Delší částí slova (**zámoř**-í -> **zámoř**-ský)
	3. Celým slovem (**tam** -> **tam**-ní)

---
#ČJ 