- jsou koncovky podle kterých určujeme (např. pád, rod, čas)

> **VZOR** NENÍ MLUVNICKÝ VÝZNAM POUZE POMŮCKA

#ČJ 