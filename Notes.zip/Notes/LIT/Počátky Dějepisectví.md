# Počátky Dějepisectví

- Snahou orbozenců bylo objektivně popsat  české dějiny, protoře měli k dispozici pouze Hájkovu kroniku, snažili se o její přepsání

### Gelasius Dobner
- Jako první odhalil nespolehlivost Hájkovy Kroniky

### František Martin Pelcl
- Přepracoval Hájkovu kroniku -> Nová kronika česká

---
#LIT 