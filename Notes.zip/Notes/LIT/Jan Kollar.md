# Jan Kollar

*(1793-1852)*
- Studoval v německu, zamiloval se zde do Němky - Mína
- Představitel [[Slavjanofilie a Rusofilie|slavjanofilie]] - Slávy dcera (rozsáhlá báseňská sbírka -> skladba)
- Putování básníka po slovanských zemích (Slované dobří, Němci zlí)
- Sláva, Slávie - bohyně Slovanů
- Slávy dcera je tendenční sbírkou

---
#LIT 