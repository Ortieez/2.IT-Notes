# František Palacký

*(1798-1876)*
- Dějiny národa českého v Čechách i v Moravě (do r.1526)
- Přítel a politický kolega Karel Havlíček Borovský
- Palacký je autorem myšlenky tzv. Austroslavismu - hájí spojení Rakouska a Slovanů jako protiváhu Německa a Ruska

---
#LIT 