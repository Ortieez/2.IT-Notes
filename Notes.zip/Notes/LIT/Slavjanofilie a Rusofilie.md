# Slavjanofilie a Rusofilie

- Přehnaná láska a obdiv ke všemu slovanskému a ruskému
- Představa, že rusko ochrání ostatní slovany proti Němcům
- Tyto naivní myšlenky se projevily i v literatuře

---
#LIT 