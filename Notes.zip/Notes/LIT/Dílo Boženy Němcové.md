# Dílo Boženy němcové
- Pohádky:
	- Lidová slovesnost (Sedmero krkavců, Pyšná princezna, Princezna se zlatou hvězdou na čele, Sůl nad zlato)

- Povídky - ženská hrdinka

- Divá Bára:
	- Vyjímečná, chová se jako kluk, všichní jí pohrdají kvůli jejímu charakteru



#LIT 