# Karel Havlíček Borovský
*(1821-1856)*

- narozen v Borové u Německého Brodu - zámožná kupecká rodina
- studoval gymnázium a kněžský seminář
- odešel ze semináře a ve svém díle církev ostře kritizuje
- 1842 - vychovatel v Rusku
- působil jako novinář (kritizoval i poměry ve státě, hlavně vláda a Habsburkové)

- celý byl pronásledován policií a úřady, několikrát mu zakázali jeho noviny
- 1851 - do vyhnanství do tyrolského Brixenu, zde onemocněl a po návratu do Prahy v roce 1856 zemřel na souchotiny

- [[Dílo Karla Havlíčka Borovského]]

#LIT 