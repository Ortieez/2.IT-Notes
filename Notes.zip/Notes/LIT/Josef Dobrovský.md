# Josef Dobrovský

*(1753-1829)*
- Jazykovědec, historik, stanovil pravidla českého jazyka a napasl první slovník
- Psal latinsky a německy, českému jazyku příliš nevěřil
- **Základní mluvnice českého jazyka**
- **Dějiny české řeči a literatury**
- Založil slavistiku = věda o Slovanech

---
#LIT 