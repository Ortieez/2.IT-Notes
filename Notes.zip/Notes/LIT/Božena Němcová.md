# Božena Němcová
*([[Český realismus v 50. století]])*

*(1820 - 1862)*
- Z chudší rodiny, dětství v Ratibořicích
- Narozena ve Vídni, otec pracoval jako Kočí a správce u Kněžny Zaháňské
- Magdaléna Novotná = její babička
- Vlastním jménem Barbora Panklová později Božena Němcová -> **pseudonym**

- Časté stěhování - manžel byl celnák - bída
- Psala články, které se neustále překládaly
- Ke konci života onemocněla a zemřela (tuberkulóza)

- díla Boženy Němcové jsou *naivni* 
- tematika: sebevědomí a emancipace = hnutí mezi ženami, společnost, ve které žijeme je patriarchální
- **emancipovaná žena** = sebevědomá žena se svým názorem
- Němcová = zakladatelka emancipačního hnutí
- v [[Povídky Boženy Němcové|povídkách]] jsou kladní hrdinové, aby literatura vychovávala

---
#LIT