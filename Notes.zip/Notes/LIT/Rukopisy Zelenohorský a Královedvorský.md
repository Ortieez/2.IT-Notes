# Rukopisy Zelenohorský a Královedvorský

- Padělky (falzifikáty)
- Ve 20. Letech 19. Století považovány za pravé
- Pravosti nevěřil Josef Dobrovský 
- Celá řada expertních posudků (vědecké, Tomáš Garrigue Masaryk - zasloužil o odhalení nepravosti)
- Pozdvihly národní sebevědomí Čechů

---
#LIT 