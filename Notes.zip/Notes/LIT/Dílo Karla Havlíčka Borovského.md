# Dílo Karla Havlíčka Borovského
- nejvýznamnější tři satirické básnické skladby
- **Král Lávra**
- **Tyrolské elegie** - žalozpěvy (zatčení a deportace do Brixenu)
- **Křest svatého Vladimíra** - kritika a výsměch církvi
- **epigramy** - krátké výsměšné básně
- Král lávra a Tyrolské elegie - napsány v exilu v Brixenu

#LIT