# Babička
- podtitul Obrazy z venkovského života
- pohodové a nekonfliktní dílo
- psychohygiena - očista duše
- autobiografické rysy
- idealizované postavy - bezchybné  postavy
- typizované postavy - klasická postava té doby

#LIT 