# Národní Obrození

### Počátky novinářství
1 český novinář - Václav Matěj Kramerius
1 české noviny - Kramérovy noviny
1 české nakladatelství - Česká expedice
1 český časopis roku 1834 - Květy (J. K. Tyl)

- Jedna z mála možností zábavy a šíření informací
- 1. Divadla byla kočovná (Martin Kopecký - loutkové divadlo)
- 1. Kamenné divadlo bylo v Praze - Stavovské divadlo
- Hrálo se německy, občas česky
- 1. české divadlo - bouda

---

### 1. Fáze
*toto téma patří k českému obrození, které mám zapsané v sešitě*

- zpočátku se česky mluvilo jen na venkově, čeština neměla žádná ustavená a ustálená pravidla
- český jazyk se pomalu dostáva i do školství - 1. fakulta českého jazyka na Karlo-Ferdinandově univerzitě v Praze (1. učitel českého jazyka =  [[Počátky Dějepisectví|František Martin Pelcl]])
- Hlavní postavou v obrození byl [[Josef Dobrovský]]


### 2. Fáze
(20. A 30. Léta 19. Století)
- Útočná fáze (rozvoj čestiny a kultury)
- Klíčová osobnost: Josef Jungmann (1773-1847)
- Jeho hlavním dílem je německo-český slovník (použil starší české výrazy = historismy a archaismy, ostatní slovanské jazyky, nová slova = neologismy)


### 3. Fáze

Hlavní osobou v této fázi byla [[Božena Němcová]]

---
#LIT 