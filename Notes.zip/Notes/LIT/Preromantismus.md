# Preromantismus
- označován též pojmem **sentimentalismus**
- 2\. polovina 18. století = předchůdce romantismu
- literární směr zdůrazňující city a emoce
- soustřeďuje se na obyčejného, prostého a nezkaženého člověka (mladí hrdinové)
- prostředí rovněž čisté a nezkažené (příroda, exotické prostředí)

- ideální čistá a nezkažená minulost, naopak je vždycky špatná přítomnost
- typičtí hrdinové (poustevníci, mniši, vězni - nespravedlivě odsouzeni, tuláci a poustevníci)
- typické prostředí (jezero, hřbitov, ostrov, hrad (noc), les)

- v oblasti umění mluvíme o klasicismu - umělecký směr aristokracie
- měšťanstvo - nový životní postoj a umělecký styl
- protest proti nespravedlnosti a poutům feudalismu, odpor k chladnému rozumářství 
- zdůrazňování citových hodnot prostého, "nezkaženého člověka"