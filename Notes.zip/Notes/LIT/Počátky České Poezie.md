# Počátky České Poezie

- Velmi naivní a jednoduché básničky
- Vycházely hlavně almanachy (soubor textů od různých autorů)
- Hodně se objevují překlady cizích autorů

### Václav Thám
- Básně a řeči (Almanach - 1783)

### Jaroslav Antonín Puchmajer
- Sebrání básní a zpěvů 1795

---
#LIT 