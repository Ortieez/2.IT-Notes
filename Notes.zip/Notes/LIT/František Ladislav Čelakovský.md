# František Ladislav Čelakovský

*(1799-1852)*
- Představitel [[Slavjanofilie a Rusofilie|rusofilie]]
- **Ohlasová poezie** - vychází z lidové slovesnosti a napodobuje ji
- 2 básnické sbírky:
	- **Ohlas písní českých** - poezie (epická a zároveň přírodní a lyrická)
	- **Ohlas písní ruských** - ruská hrdinská epika (hrdina Ilja Murovec)


---
#LIT 