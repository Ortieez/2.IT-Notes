# Monitory
-  výstupní zobrazovací zařízení

- obraz je skládán z mnoha malých bodů, které mají určitý odstín

- výsledný odstín vytvořen v režimu RGB (red, green,blue)

- 24 bitová barevná hloubka - 16,7 milionu odstínů (někdy až 30 bit)

## Rozdělení
- **CRT** – Cathode Ray Tube
	- obraz tvořen pomocí elektronových paprsků
	- už se moc nepoužívá

- **LCD** – Liquid Crystal Display
	- obraz tvořen pomocí tekutých krystalů
	- nyní většinou LED podsvícení (LED monitory)
	- mohou být dotykové
	- mohou umět 3D zobrazení

#PHW 