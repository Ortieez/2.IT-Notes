# Jehličkové Tiskárny

### Princip
- jehličkový tisk (dot matrix print) - pohyb jehličky směrem k papíru
- zanechá grafickou stopu pomocí pásky namočené v inkoustu

- písmena a grafika z jednotlivých bodů

### Tiskové Jehličky
- každý bod zaznamenán kovovou jehličkou, která se pomocí řízeného dodání energie do malého elektromagnetu

#PHW 