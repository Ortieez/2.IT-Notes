### Herní Zařízení

- 3 typy:
	- pákové (joysticky)
	- křížové (gamepady)
	- volanty/pedály

- Podle připojení:
	- drátové
		- USB/Gameport
	- bezdrátové
		- pomocí BT/rádiové

- Forcefeedback - zpětná vazba / odezva na dění ve hře, většinou pomocí silné vibrace, ztuhne řízení apod.

---

#PHW 