# Klávesnice
(*Dao Maxmilián, Adam Zárowny*)

- Typy klávesnic
	- GMK
	- MK s Pěnovým prvkem
	- MK s gumovou membránou
	- K s kapacittivními spínači
	- Membránové K
	- Laserové K

- Typ připojení
	- Bezdrát
		- iRDA (IR)
		- Rádiové/Wifi
		- Bluetooth
	- Kabelové (DIN 9, PS/2)

- alfanumerická část
- numerická část
- speciální a editační klávesy
- funkční klávesy

---

#PHW