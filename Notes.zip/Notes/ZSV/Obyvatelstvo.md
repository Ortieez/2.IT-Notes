# Obyvatelstvo

- Stát má občany - zákon č.40/1993 (č.186/2013) Sb., o nabývání a pozbývání státního občanství České republiky
- Existence nového státu a spolupráce - ostatní státy musí uznat nově vzniklý za samostatný subjekt mezinárodního práva
- Stát je subjektem mezinárodního práva: Např. Dne 21. Května 2008 Česká republika uznala nezávislost Kosova


---
#ZSV 