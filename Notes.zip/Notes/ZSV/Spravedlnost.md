# Spravedlnost

- Jeden ze základních pojmů pro dobré uspořádání lidských vztahů
- Regulativní idea pro uspořádání společnosti
- základní pojem pro právo
- Podle Aristotela = nejdůležitější ctnost, vztahuje se ke druhému a nazývá se také dobro pro druhé

---

### Charakteristika
1) rovné zacházení se všemi - spravedlnost jako rovnost před zákonem
2) přiměřené tresty i odměny - retributivní spravedlnost
3) spravedlivé rozdělování požitků i břemen - distributivní spravedlnost
4) rozhodovat stejné případy stejně a nestejné odlišné - procesní spravedlnost

---
#ZSV 