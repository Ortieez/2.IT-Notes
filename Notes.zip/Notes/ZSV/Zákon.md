# Zákon 
- základní druh obecně závazného právního předpisu
- platný pro státní orgány, právnické i fyzické osoby 
- výraz svrchovanosti a nezávislosti státní moci = *státní suverenita*

- nadřazené zákony ústavní, jejich druhem ústava - jiná forma 
- soubory uspořádaných norem hmotného práva = **zákoníky** ([[Právo#^748c53|občanský zákoník]], zákoník práce...) 

- zákon pro procesní právo = *řád* (trestní řád...)
- změny a úpravy zákona prostřednictvím novel
- přednost novelizovaného zákona před zněním pďvodním
- zveřejnění ve **Sbírce zákonů** 

#ZSV 