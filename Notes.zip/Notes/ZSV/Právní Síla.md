- závisí na tom, který státní orgán předpis vydal a jak se předpis nazývá

---
#ZSV 