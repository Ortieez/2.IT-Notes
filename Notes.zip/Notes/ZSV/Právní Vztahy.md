# Právní Vztahy

- vztah mezi nejméně dvěma subjekty práva, v němž tyto subjekty navzájem vystupují jako nositelí subjektivních práv a povinnosti
- a) dána právní norma určující rozsah oprávnění a povinnosti subjektů právního vztahu
- b) právní skutečnost (např. pracovní smlouva, ...)

#ZSV 