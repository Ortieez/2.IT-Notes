# Charakteristické Rysy Právního Řádu ČR

- Uzavřený myšlenkový celek 
	- odlišuje se od právních rádů ostatních států

- **logický celek právních norem** - normy se vzájemně obsahově doplňují a navazují na sebe, nesmějí být rozporné (dbá na to Ústavní soud a orgány moci výkonné zákonodárné a soudní)

- Normy právního řádu jsou projevem jediné vůle
	- vůle právotvorných (legislativních) orgánů státu

- Právní řád se neustále vyvíjí a mění
	- neustále vstupují nové normy a zastaralé z něj mizí

- Sbližování právních řádů evropských států

---
#ZSV 