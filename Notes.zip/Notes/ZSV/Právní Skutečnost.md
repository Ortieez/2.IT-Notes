# Právní Skutečnost
- objektivní - nezávisí na lidské vůli (př. plynutí času)
- subjektivní - závisí na lidské vůli
1. právní jednání - (např. uzavření kupní smlouvy...)
2. protiprávní jednání - (např. krádež, vražda...)

#ZSV