# Právní Ochrana v České Republice

- orgány:
	- právní ochrany = orgány zřízené státem zajišťující dodržování práva
	- disponují státní moci v podobě vynucovacích nástrojů
	- usillují o znovuobonovení právního stavu

	- *soudy, státní zastupitesltví, Policie ČR, ale i advokáti, notáři či exekutoři*

#ZSV 