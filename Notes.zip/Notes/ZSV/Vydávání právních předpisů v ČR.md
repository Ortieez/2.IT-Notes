# Vydávání právních předpisů v ČR

- **orgán zákonodárné moci**
	- právní předpis = Parlament ČR
		- ústavní zákony, zákony, zákonná opatření

- **orgány výkonné moci**
	- právní předpis:
		- vláda -> nařízení
		- ministerstva a jiné správní orgány -> vyhlášky

- **orgány územní samosprávy**
	-  právní předpis:
		- kraje -> vyhlášky, nařízení
		- obce -> vyhlášky, nařízení


#ZSV 