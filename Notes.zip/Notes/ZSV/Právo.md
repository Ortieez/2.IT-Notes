# Právo

- soubor pravidel, podle kterých se organizuje a řídí lidské spolužití
- historický vývoj práva od nepsaných právních obyčejů k soudobé písemné formě právních předpisů (edited)

- Objektivní (abstrakní - blíže neurčené množství osob) -> law -> souhrn norem 
- Subjektivní (konktrétní - blíže určené osoby) -> right -> oprávnění

1) právo objektivní = zákony a jiné právní předpisy 
	- Upravuje společenské vztahy všeobecně
2) právo subjektivní = vyjadřuje oprávnění (míra právní možnosti chování) 	účastníka právního vztahu

- S některými subjektivními právy je spojena odpovědnost

- Vztah objektivního a subjektivního prává = vztah abstraktního a konkrétního pojetí práva
- Objektivní právo = občanský zákoník ustanovuje, jak má nájemce platit pronajímateli nájemné a každý pronajímatel ^748c53
- Subjektivní právo = konkrétní pronajímatel má právo (moc) vynutit na svém určitém nájemci zaplacení nájemného 

---
#ZSV 