potvrzení, schválení, souhlas se smlouvou


---
#ZSV