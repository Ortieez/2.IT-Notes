# Stát

- Organizační soustava lidské společnosti
- Soustava má své:
	1) ohraničení území (prostor pod zemí, prostor na povrchu země, vzdušný prostor)
	2) občany ([[Obyvatelstvo]])
	3) řídící orgány, administrativní aparát a ozbrojenou moc

1. Před vznikem státu:
	- Nejsou závazná pravidla > chování neřízeně > **CHAOS** > hrozí rozpad celku (kmene, rodu)
2. Stát:
	- Stanoví pravidla > chování vynucené > **ŘÁD** > celek se udržuje

---

- stát vydává všeobecně závazná pravidla (předpisy) 
	- prostřednictvím řídících orgánů 
- pravidla právem příslušného státu 
- předpisy: 
	1. usměrnění chování obyvatelstva 
	2. usměrnění různých organizací 
	3. usměrnění statního administrativního aparátu (statních orgánů)
	
- stát = společenský organismus 
- [[Právo]] = prostředek k udržení jeho životaschopnosti 
- stát právem organizuje život na svém území a chrání zájmy jednotlivých obyvatel i celé společnosti 
- [[Spravedlnost]]

- stát vynucuje dodržování pravních předpisů - prostřednictvím administrativního aparátu a ozbrojené moci (edited)


---
#ZSV 