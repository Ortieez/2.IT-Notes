použití, realizace právního předpisu v praxi
#ZSV 