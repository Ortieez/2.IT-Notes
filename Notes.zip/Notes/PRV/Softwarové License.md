# Softwarové License

### Autorské právo
- Copyright
- Zabývá se právními vztahy mezi uživately a autory SW
- Autorské právo je součástí duševního vlastnictví
- Autorem fyzická osoba (programátor)

1) Osobní 
	1) autorské právo platí do smrti
	2) autor nemůže převést právo nebo se ho vzdát
2) Majetková
	1) 70 let po smrti končí
	2) když není znám autor končí 70 let po vydání díla

1) Omezení
	1) chráněno pouze díl
	2) dovoleno citovat
	3) lze používat pro osobní potřebu, nelze dál šířit

---

### SW License
- Autor může licence měnit
- Při instalaci sw je potřeba odsouhlasit licenční smlouvu
- Licence stanovuje podmínky užívání
- Umožňuje uživateli redistribuovat ten určitý SW

---

### Legální SW
- Kontrolu řeší speciální oddělení policie ČR
- Ochrana před nelegálním kopírováním:
	- Sériové číslo
	- Hw klíč
	- Aktivace programu
- Překonání ochran je nelegální

---
#PRV
